import React from "react";


import { Routes, Route } from "react-router-dom";
import { CartProvider } from "./contexts/CartContext";
import Layout from "./components/Layout";
import ProductList from "./components/ProductList";
import ProductDetail from "./components/ProductDetail";
import Cart from "./components/Cart";
import ProtectedRoute from "./components/ProtectedRoute";


function About() {
  return <div><h3>About</h3><p>Proyecto pre-entrega React + Bootstrap</p></div>;
}

function Login({ onLogin }) {
  return (
    <div className="card mx-auto" style={{maxWidth:500}}>
      <div className="card-body">
        <h5 className="card-title">Login demo</h5>
        <p>Haz click para simular autenticación (para rutas protegidas).</p>
        <button className="btn btn-primary" onClick={onLogin}>Iniciar sesión</button>
      </div>
    </div>
  );
}

function Checkout() {
  return <div><h3>Checkout</h3><p>Zona protegida — aquí procesarías el pago real.</p></div>;
}




export default function App() {
  return (
    <>
    <div className="container mt-5">
      <h1>¡Mi App de Compras funciona!</h1>
    </div>





<CartProvider>
      <Layout>
        <Routes>
          <Route path="/" element={<ProductList />} />
          <Route path="/about" element={<About />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/login" element={<Login onLogin={() => setIsAuthenticated(true)} />} />

          {/* Ruta protegida */}
          <Route path="/checkout" element={
            <ProtectedRoute isAuthenticated={isAuthenticated}>
              <Checkout />
            </ProtectedRoute>
          } />

          {/* fallback */}
          <Route path="*" element={<div className="text-center py-5">Página no encontrada</div>} />
        </Routes>
      </Layout>
    </CartProvider>



    </>



  );
}
