import React, { createContext, useState } from "react";

export const CartContext = createContext();

export function CartProvider({ children }) {
  const [cartItems, setCartItems] = useState([]); // useState requerido por el enunciado

  function addToCart(product) {
    setCartItems(prev => {
      const found = prev.find(p => p.id === product.id);
      if (found) {
        return prev.map(p => p.id === product.id ? { ...p, qty: p.qty + 1 } : p);
      }
      return [...prev, { ...product, qty: 1 }];
    });
  }

  function removeFromCart(productId) {
    setCartItems(prev => prev.filter(p => p.id !== productId));
  }

  function updateQty(productId, qty) {
    setCartItems(prev => prev.map(p => p.id === productId ? { ...p, qty } : p));
  }

  function clearCart() {
    setCartItems([]);
  }

  const total = cartItems.reduce((s, p) => s + p.price * p.qty, 0);

  return (
    <CartContext.Provider value={{ cartItems, addToCart, removeFromCart, updateQty, clearCart, total }}>
      {children}
    </CartContext.Provider>
  );
}
