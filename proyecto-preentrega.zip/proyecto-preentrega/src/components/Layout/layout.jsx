import React from "react";
import AppNavbar from "./Navbar";

export default function Layout({ children }) {
  return (
    <>
      <AppNavbar />
      <main className="container my-4">
        {children}
      </main>
    </>
  );
}
