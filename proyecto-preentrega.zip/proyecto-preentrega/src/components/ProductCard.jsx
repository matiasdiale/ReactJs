import React from "react";
import { Link } from "react-router-dom";

export default function ProductCard({ product, onAdd }) {
  return (
    <div className="card h-100">
      <img src={product.image} className="card-img-top p-3" style={{height:160, objectFit:"contain"}} alt={product.title} />
      <div className="card-body d-flex flex-column">
        <h6 className="card-title" style={{fontSize:14}}>{product.title}</h6>
        <p className="card-text fst-italic mb-1" style={{fontSize:13}}>${product.price.toFixed(2)}</p>
        <div className="mt-auto d-flex gap-2">
          <Link to={`/product/${product.id}`} className="btn btn-outline-primary btn-sm">Ver</Link>
          <button className="btn btn-primary btn-sm" onClick={onAdd}>Agregar</button>
        </div>
      </div>
    </div>
  );
}
