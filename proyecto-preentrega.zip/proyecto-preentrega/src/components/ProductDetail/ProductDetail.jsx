import React, { useEffect, useState, useContext } from "react";
import { useParams } from "react-router-dom";
import { fetchProductById } from "../api";
import { CartContext } from "../contexts/CartContext";

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { addToCart } = useContext(CartContext);

  useEffect(() => {
    setLoading(true);
    fetchProductById(id)
      .then(data => { setProduct(data); setError(null); })
      .catch(err => setError(err.message || "Error"))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="text-center py-5">Cargando producto...</div>;
  if (error) return <div className="alert alert-danger">{error}</div>;
  if (!product) return null;

  return (
    <div className="row">
      <div className="col-md-5">
        <img src={product.image} alt={product.title} className="img-fluid" style={{maxHeight:400, objectFit:"contain"}} />
      </div>
      <div className="col-md-7">
        <h3>{product.title}</h3>
        <p className="lead">${product.price.toFixed(2)}</p>
        <p>{product.description}</p>
        <button className="btn btn-success me-2" onClick={() => addToCart(product)}>Agregar al carrito</button>
      </div>
    </div>
  );
}
