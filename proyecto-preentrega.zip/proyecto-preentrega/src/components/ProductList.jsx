import React, { useEffect, useState, useContext } from "react";
import { fetchProducts } from "../api";
import ProductCard from "./ProductCard";
import { CartContext } from "../contexts/CartContext";

export default function ProductList() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { addToCart } = useContext(CartContext);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    fetchProducts()
      .then(data => {
        if (mounted) {
          setProducts(data);
          setError(null);
        }
      })
      .catch(err => {
        if (mounted) setError(err.message || "Error");
      })
      .finally(() => mounted && setLoading(false));
    return () => { mounted = false; }
  }, []);

  if (loading) return <div className="text-center py-5">Cargando productos...</div>;
  if (error) return <div className="alert alert-danger">Error: {error}</div>;

  return (
    <div className="row">
      {products.map(p => (
        <div className="col-sm-6 col-md-4 col-lg-3 mb-4" key={p.id}>
          <ProductCard product={p} onAdd={() => addToCart(p)} />
        </div>
      ))}
    </div>
  );
}
