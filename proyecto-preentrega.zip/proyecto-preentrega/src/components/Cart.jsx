import React, { useContext } from "react";
import { CartContext } from "../contexts/CartContext";
import { Link } from "react-router-dom";

export default function Cart() {
  const { cartItems, removeFromCart, updateQty, total, clearCart } = useContext(CartContext);

  if (cartItems.length === 0) {
    return (
      <div className="text-center py-5">
        <h4>Tu carrito está vacío</h4>
        <Link to="/" className="btn btn-primary mt-3">Ver productos</Link>
      </div>
    );
  }

  return (
    <div>
      <h4>Carrito</h4>
      <div className="list-group mb-3">
        {cartItems.map(item => (
          <div key={item.id} className="list-group-item d-flex align-items-center">
            <img src={item.image} alt={item.title} style={{width:60, height:60, objectFit:"contain"}} className="me-3" />
            <div className="flex-grow-1">
              <div>{item.title}</div>
              <small>${item.price.toFixed(2)}</small>
            </div>
            <div className="d-flex align-items-center gap-2">
              <input type="number" min="1" value={item.qty} onChange={e => updateQty(item.id, Math.max(1, Number(e.target.value)))} style={{width:70}} />
              <button className="btn btn-sm btn-outline-danger" onClick={() => removeFromCart(item.id)}>Quitar</button>
            </div>
          </div>
        ))}
      </div>

      <div className="d-flex justify-content-between align-items-center">
        <strong>Total: ${total.toFixed(2)}</strong>
        <div>
          <button className="btn btn-outline-secondary me-2" onClick={clearCart}>Vaciar</button>
          <Link to="/checkout" className="btn btn-success">Ir a pagar</Link>
        </div>
      </div>
    </div>
  );
}
